#ifndef FIFTEEN_H
#define FIFTEEN_H

#include "raylib.h"
#include "player.h"

void HandleCaseFifteen(Player *player, int totalCases, Font font,
                       bool *trapActive15, float *trapTimer15);

#endif
