#ifndef DICE3D_H
#define DICE3D_H

#include "raylib.h"

// Lance une animation de dé 3D et retourne le résultat final (1–6)
int LaunchDice3D(Font font);

#endif
