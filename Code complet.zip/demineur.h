#ifndef DEMINEUR_H
#define DEMINEUR_H

int StartDemineur(int level);

#endif
