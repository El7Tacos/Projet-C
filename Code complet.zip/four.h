#ifndef FOUR_H
#define FOUR_H

#include "raylib.h"
#include "player.h"

void HandleCaseFour(Player *player, int totalCases, Font font,
                    bool *trapActive4, float *trapTimer4);

#endif
