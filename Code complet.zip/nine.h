// five.h
#ifndef NINE_H
#define NINE_H

#include "raylib.h"
#include "player.h"

void HandleCaseNine(Player *player, int totalCases, Font font, bool *trapActive, float *trapTimer);

#endif
