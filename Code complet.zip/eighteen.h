#ifndef EIGHTEEN_H
#define EIGHTEEN_H

#include "raylib.h"
#include "player.h"

// Case 18 → retour au départ
void HandleCaseEighteen(Player *player, int totalCases, Font font, bool *trapActive18, float *trapTimer18);

#endif
